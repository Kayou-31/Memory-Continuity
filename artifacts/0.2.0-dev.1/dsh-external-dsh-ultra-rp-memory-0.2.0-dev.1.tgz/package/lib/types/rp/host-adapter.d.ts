/** Native completion is observation only (source-adapter). P0 found no reliable
 * native selection or revision event. Native lineage can be inspected, but is
 * not a supported RP canonical fork mutation and must not create a branch. */
import type { HostAuthority, Result } from './types.js';
import type { createCanonicalService } from './canonical.js';
export declare function applyNativeCanonicalEvent(_service: ReturnType<typeof createCanonicalService>, _authority: HostAuthority, input: {
    readonly kind: string;
}): Promise<Result<never>>;
