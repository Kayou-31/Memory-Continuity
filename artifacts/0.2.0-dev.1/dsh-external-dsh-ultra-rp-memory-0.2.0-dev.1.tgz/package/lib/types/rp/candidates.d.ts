import type { EventPayload, InputFence, Result, SemanticEvent, SourceRevision, SourceSpan, Summary } from './types.js';
import type { GlobalFence } from './global.js';
export interface SummarySelection {
    level: Summary['level'];
    sourceRevisionIds: readonly string[];
    dependencySummaryIds: readonly string[];
    supportEventIds: readonly string[];
    exactAnchors?: readonly SourceSpan[];
    boundary?: 'explicit' | 'proposal';
}
export interface CandidateSnapshot {
    inputFence: InputFence;
    globalFences: readonly GlobalFence[];
    policyEpoch: number;
    selection: SummarySelection;
    sources: readonly {
        source: SourceRevision;
        text: string;
    }[];
    dependencies: readonly Summary[];
    supportEvents: readonly SemanticEvent[];
    entityIds: readonly string[];
}
export interface MemoryCandidate {
    schemaVersion: 1;
    id: string;
    inputFence: InputFence;
    proposedEvents: readonly {
        payload: EventPayload;
        epistemic: SemanticEvent['epistemic'];
        beliefHolderId?: string;
        sources: readonly SourceSpan[];
    }[];
    proposedSummary?: {
        level: Summary['level'];
        text: string;
        sourceRevisionIds: readonly string[];
        exactAnchors: readonly SourceSpan[];
    };
    sceneBoundaryHint?: 'scene_end';
}
export interface SavedCandidate {
    candidate: MemoryCandidate;
    globalFences: readonly GlobalFence[];
    policyEpoch: number;
    selection: SummarySelection;
}
export declare function verifyCandidateSpan(span: SourceSpan, snapshot: CandidateSnapshot): void;
export declare function validateCandidate(input: unknown, snapshot: CandidateSnapshot): Result<MemoryCandidate>;
/** Fixed-output fixture annotations; no human review or model quality claim. */
export declare function scoreAnnotatedClaims(claims: readonly {
    expected: string;
    actual: string;
    critical: boolean;
}[]): {
    evaluated: number;
    supported: number;
    unsupported: number;
    criticalErrors: number;
    passed: boolean;
    method: string;
};
