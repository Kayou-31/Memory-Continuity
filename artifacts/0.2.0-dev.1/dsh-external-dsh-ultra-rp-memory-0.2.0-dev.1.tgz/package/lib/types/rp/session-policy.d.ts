export declare const SESSION_MEMORY_POLICY = "dsh.session-memory-policy/v1";
export declare const EVIDENCE_POLICY_PROTOCOL = "dsh-ultra-evidence/v2";
interface Root {
    root?: Root;
    get(key: string): any;
    provide?(key: string, value: unknown): () => unknown;
    on?(name: string, listener: any): () => unknown;
}
export type SessionMode = 'off' | 'engineering' | 'rp' | 'blocked';
export declare class MemoryCoordinator {
    private tail;
    private profileJobs;
    /** Root-shared, process-local candidate-generation slot; not a native owner lease. */
    takeProfileJob(profileId: string): (() => void) | null;
    lock(): Promise<() => void>;
    mutate<T>(work: () => Promise<T>): Promise<T>;
}
export declare class SessionMemoryPolicy {
    readonly protocol = "dsh.session-memory-policy/v1";
    readonly coordinator: MemoryCoordinator;
    private sessions;
    private writers;
    private stopped;
    private root?;
    private legacyGuard?;
    private rpSeen;
    bindRoot(root: Root, kind: string): void;
    ensureLegacyBarrier(): void;
    status(session: string): {
        mode: SessionMode;
        epoch: number;
        modeEpoch: number;
    };
    registerWriter(kind: string, writer: {
        drain(): Promise<void>;
    }): () => Promise<void>;
    activate(session: string, mode: 'rp' | 'engineering', proof: {
        idle: boolean;
        safe: boolean;
    }): Promise<{
        mode: "rp" | "engineering";
        epoch: number;
        modeEpoch: number;
    }>;
    mutate<T>(session: string | null, work: () => Promise<T>): Promise<T>;
    request(session: string, epoch: number): Promise<() => void>;
    /** Keep a closed RP session blocked: unloading must not turn it into engineering. */
    block(session: string): Promise<void>;
}
export declare function engineeringAllowed(context: {
    root?: any;
    get?(key: string): any;
} | undefined, session: string | undefined): boolean;
/** Kept root-owned even at zero plugin leases so closed RP bindings cannot fall through. */
export declare function acquireSessionPolicy(context: Root, kind: string): {
    policy: SessionMemoryPolicy;
    release: () => Promise<void>;
};
export {};
