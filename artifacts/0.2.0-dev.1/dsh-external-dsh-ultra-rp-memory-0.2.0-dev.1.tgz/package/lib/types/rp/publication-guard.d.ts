/** Trusted callers can only add checks. Nested scopes never remove outer guards. */
export declare const withPublicationGuard: <T>(guard: () => void, work: () => Promise<T>) => Promise<T>;
export declare const assertPublicationAllowed: () => void;
