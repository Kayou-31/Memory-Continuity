import { MemoryCoordinator } from './session-policy.js';
import type { HostAuthority, CanonBinding } from './types.js';
export { createRuntimeBinding, validateRuntimeBinding, MODULES, MODES, HARD_CONSTRAINTS } from './modules/contract.js';
import type { RecallOptimizer } from './memory-optimizer.js';
export { createUltraRpOptimizer } from './memory-optimizer.js';
export type { AgentMemoryControl } from './agent-memory.js';
export { scoreAnnotatedClaims, validateCandidate } from './candidates.js';
export * from './session-policy.js';
export * from './packet.js';
export * from './retrieval.js';
export { canonical } from './store.js';
export declare function openRpMemory(input: {
    profileRoot: string;
    entityIds: readonly string[];
    coordinator?: MemoryCoordinator;
    optimizer?: () => RecallOptimizer | undefined;
    verification?: (recordId: string) => Promise<'source-match' | 'unavailable' | 'hash-mismatch'>;
}): Promise<{
    store: import("./store.js").RpStore;
    control: {
        forkBranch: (authority: HostAuthority, input: import("./types.js").ForkManifest & {
            readonly idempotencyKey: string;
        }) => Promise<import("./types.js").Result<import("./types.js").Branch>>;
        privacyDelete: (authority: HostAuthority, controlSourceId: string, input: {
            readonly idempotencyKey: string;
            readonly expected: import("./types.js").InputFence;
            readonly sourceRevisionIds: readonly string[];
            readonly affectedBranchIds: readonly string[];
        }, authorities: readonly HostAuthority[]) => Promise<import("./types.js").Result<import("./types.js").PrivacyDeletion>>;
        purgePrivacy: (authority: HostAuthority, key: string, authorities?: readonly HostAuthority[]) => Promise<import("./types.js").Result<import("./types.js").PrivacyDeletion>>;
        createWorkspace: (inputRoot: string) => Promise<import("./types.js").Result<import("./types.js").WorkspaceBinding>>;
        openWorkspace: (root: string) => Promise<import("./types.js").Result<import("./types.js").WorkspaceBinding>>;
        migrateWorkspace: (authority: HostAuthority, inputRoot: string) => Promise<import("./types.js").Result<import("./types.js").WorkspaceBinding>>;
        createBranch: (workspaceId: string, campaignId: string) => Promise<import("./types.js").Result<import("./types.js").Branch>>;
        authorize: (input: import("./store.js").AuthorityRequest) => Promise<import("./types.js").Result<HostAuthority>>;
        recoverWriterLock: (authority: HostAuthority) => Promise<import("./types.js").Result<"recovered" | "unlocked">>;
    };
    global: {
        store: {
            storageStatus(authority: object): Promise<import("./types.js").Result<{
                logicalBytes: number;
                seq: number;
                publicationLimitBytes: number;
                controlLimitBytes: number;
                backupId?: string | undefined;
                backupSha256?: string | undefined;
                format: string;
            }>>;
            listActive(authority: object): Promise<import("./types.js").Result<import("./global.js").GlobalPublication[]>>;
            readFence(authority: object): Promise<import("./types.js").Result<import("./global.js").GlobalFence>>;
            readPublication: (authority: object, publicationId: string) => Promise<import("./types.js").Result<import("./global.js").GlobalPublication>>;
            list(authority: object): Promise<import("./types.js").Result<import("./global.js").GlobalPublication[]>>;
            verifyBinding(authority: object, binding: CanonBinding): Promise<boolean>;
        };
        control: {
            enableSegments(authority: object, approval: object, input: {
                idempotencyKey: string;
                expected: import("./global.js").GlobalFence;
            }): Promise<import("./types.js").Result<import("./global.js").GlobalFence>>;
            purgeStatus(authority: object): Promise<import("./types.js").Result<{
                publicationId: string;
                purgeState: string;
            }[]>>;
            isApproval(handle: object): boolean;
            authorize(input: import("./global.js").Grant): Promise<import("./types.js").Result<object>>;
            revokeAuthority(authority: object): Promise<void>;
            recoverWriterLock(authority: object): Promise<import("./types.js").Result<"unlocked" | "recovered">>;
            approval(input: {
                commandId: string;
                sessionId: string;
            }): Readonly<{}>;
            revokeApproval(handle: object): void;
            publish(authority: object, approval: object, input: {
                idempotencyKey: string;
                expected: import("./global.js").GlobalFence;
                key: string;
                body: string;
                privateSourceIds: readonly string[];
                supersedes?: string;
            }): Promise<import("./types.js").Result<import("./global.js").GlobalPublication>>;
            privateDeletion(authority: object, approval: object, input: {
                idempotencyKey: string;
                expected: import("./global.js").GlobalFence;
                privateSourceIds: readonly string[];
                publicationDisposition: "retain" | "delete";
            }): Promise<import("./types.js").Result<import("./global.js").GlobalFence>>;
            revoke(authority: object, approval: object, input: {
                idempotencyKey: string;
                expected: import("./global.js").GlobalFence;
                publicationId: string;
            }): Promise<import("./types.js").Result<import("./global.js").GlobalFence>>;
        };
    };
    canonical: Readonly<{
        forkManifest: (authority: HostAuthority, revision: number) => Promise<import("./types.js").Result<import("./types.js").ForkManifest>>;
        forkBranch: (authority: HostAuthority, manifest: import("./types.js").ForkManifest & {
            readonly idempotencyKey: string;
        }) => Promise<import("./types.js").Result<import("./types.js").Branch>>;
        resumePrivacyDelete: (authority: HostAuthority, key: string, affectedAuthorities?: readonly HostAuthority[]) => Promise<import("./types.js").Result<import("./types.js").PrivacyDeletion>>;
        applyCanonicalChange(change: import("./canonical.js").CanonicalControl, authority: HostAuthority, userControlSource: import("./types.js").SourceRevision): Promise<{
            readonly ok: false;
            readonly code: import("./types.js").ErrorCode;
            readonly message: string;
        } | {
            readonly ok: true;
            readonly value: import("./types.js").InputFence;
        } | {
            readonly ok: true;
            readonly value: import("./types.js").PrivacyDeletion;
        }>;
        applyControl(authority: HostAuthority, userControlSource: import("./types.js").SourceRevision, input: import("./canonical.js").CanonicalControl, affectedAuthorities?: readonly HostAuthority[]): Promise<{
            readonly ok: false;
            readonly code: import("./types.js").ErrorCode;
            readonly message: string;
        } | {
            readonly ok: true;
            readonly value: import("./types.js").InputFence;
        } | {
            readonly ok: true;
            readonly value: import("./types.js").PrivacyDeletion;
        }>;
    }>;
    person: Readonly<{
        preview(authority: HostAuthority, input: unknown, key: string): Promise<{
            ok: false;
            code: import("./types.js").ErrorCode;
            message: string;
        } | {
            ok: true;
            value: {
                handle: Readonly<{}>;
                personId: string;
                draftHash: string;
                inputFence: import("./types.js").InputFence;
                draft: import("./person/types.js").PersonDraft;
                backupRequired: boolean;
            };
        }>;
        confirm(authority: HostAuthority, handle: object, controlSource: import("./types.js").SourceRevision): Promise<{
            readonly ok: false;
            readonly code: import("./types.js").ErrorCode;
            readonly message: string;
        } | {
            ok: true;
            value: {
                personId: string;
                originEventId: string;
                fence: import("./types.js").InputFence;
            };
        }>;
        read(authority: HostAuthority, personId: string): Promise<import("./types.js").Result<{
            personId: string;
            originEventId: string;
            fence: import("./types.js").InputFence;
            fields: {
                eventId: string;
                protocol: "person-core/v1";
                operation: "init" | "edit" | "grow" | "set-policy";
                previousEventId: string | null;
                causeEventIds: string[];
                note: string;
                fieldId: string;
                kind: import("./person/types.js").PersonFieldKind;
                value: string;
                policy: import("./person/types.js").PersonPolicy;
                validity?: import("./person/types.js").PersonValidity;
            }[];
            relationships: import("./types.js").RelationshipProjection[];
            goals: import("./types.js").StateProjection[];
        }>>;
        apply(authority: HostAuthority, control: import("./types.js").SourceRevision, input: unknown): Promise<{
            ok: false;
            code: import("./types.js").ErrorCode;
            message: string;
        } | {
            ok: true;
            value: {
                eventId: string;
                fence: import("./types.js").InputFence | import("./types.js").PrivacyDeletion;
            };
        }>;
        propose: (authority: HostAuthority, input: unknown, key: string, expected?: import("./types.js").InputFence) => Promise<import("./types.js").Result<{
            protocol: "person-growth/v1";
            id: string;
            inputFence: import("./types.js").InputFence;
            changes: ({
                changeId: string;
                personId: string;
                fieldId: string;
                previousEventId: string | null;
                previousChangeId?: string;
                value: string;
                causeEventIds: string[];
                note: string;
            } & {
                eventId: string;
            })[];
        }>>;
        list(authority: HostAuthority): Promise<import("./types.js").Result<{
            state: any;
            protocol: "person-growth/v1";
            id: string;
            inputFence: import("./types.js").InputFence;
            changes: ({
                changeId: string;
                personId: string;
                fieldId: string;
                previousEventId: string | null;
                previousChangeId?: string;
                value: string;
                causeEventIds: string[];
                note: string;
            } & {
                eventId: string;
            })[];
        }[]>>;
        adopt(authority: HostAuthority, control: import("./types.js").SourceRevision, candidateIds: readonly string[], key: string): Promise<{
            ok: false;
            code: import("./types.js").ErrorCode;
            message: string;
        } | {
            ok: true;
            value: {
                fence: import("./types.js").InputFence | import("./types.js").PrivacyDeletion;
            };
        }>;
        reject(authority: HostAuthority, control: import("./types.js").SourceRevision, candidateId: string, key: string, originalExpected?: import("./types.js").InputFence): Promise<{
            readonly ok: false;
            readonly code: import("./types.js").ErrorCode;
            readonly message: string;
        } | {
            readonly ok: true;
            readonly value: import("./types.js").InputFence;
        } | {
            readonly ok: true;
            readonly value: import("./types.js").PrivacyDeletion;
        }>;
        timeline(authority: HostAuthority, personId: string): Promise<import("./types.js").Result<{
            personId: string;
            fence: import("./types.js").InputFence;
            originEventId: string;
            changes: {
                eventId: string;
                acceptedSeq: number;
                fictionalTime: string | null;
                sourceRevisionIds: string[];
                current: boolean;
                expired: boolean;
                protocol: "person-core/v1";
                operation: "init" | "edit" | "grow" | "set-policy";
                previousEventId: string | null;
                causeEventIds: string[];
                note: string;
                fieldId: string;
                kind: import("./person/types.js").PersonFieldKind;
                value: string;
                policy: import("./person/types.js").PersonPolicy;
                validity?: import("./person/types.js").PersonValidity;
            }[];
            invalidatedEventIds: string[];
        }>>;
    }>;
    agentMemory: Readonly<{
        apply(authority: HostAuthority, controlSource: import("./types.js").SourceRevision, input: import("./agent-memory.js").AgentMemoryControl): Promise<{
            readonly ok: false;
            readonly code: import("./types.js").ErrorCode;
            readonly message: string;
        } | {
            ok: true;
            value: {
                eventId: string;
                fence: import("./types.js").InputFence;
            };
        }>;
    }>;
    summaries: {
        capture: (authority: HostAuthority, raw: import("./candidates.js").SummarySelection, options?: import("./summarizer.js").SummaryContext) => Promise<import("./candidates.js").CandidateSnapshot>;
        guard: (authority: HostAuthority, snapshot: Pick<import("./candidates.js").CandidateSnapshot, "inputFence" | "globalFences" | "policyEpoch">, options: import("./summarizer.js").SummaryContext) => Promise<void>;
        generatorInput: (snapshot: import("./candidates.js").CandidateSnapshot) => {
            schemaVersion: number;
            level: "scene" | "chapter" | "arc";
            inputFence: import("./types.js").InputFence;
            sources: {
                id: string;
                text: string;
                span: {
                    sourceRevisionId: string;
                    publicTextSha256: string;
                    startUtf16: number;
                    endUtf16: number;
                    quoteSha256: string;
                };
            }[];
            childSummaries: readonly import("./types.js").Summary[];
            supportEvents: readonly import("./types.js").SemanticEvent[];
            entityIds: readonly string[];
            boundary: "explicit" | "proposal";
            rules: string;
        };
        propose(authority: HostAuthority, raw: unknown, selection: import("./candidates.js").SummarySelection, options?: import("./summarizer.js").SummaryContext): Promise<{
            ok: false;
            code: import("./types.js").ErrorCode;
            message: string;
        } | {
            ok: true;
            value: {
                id: string;
                state: "pending";
                inputFence: import("./types.js").InputFence;
                hasSummary: boolean;
                eventCount: number;
            };
        }>;
        fromGenerated(authority: HostAuthority, raw: unknown, snapshot: import("./candidates.js").CandidateSnapshot, options?: import("./summarizer.js").SummaryContext): Promise<{
            id: string;
            state: "pending";
            inputFence: import("./types.js").InputFence;
            hasSummary: boolean;
            eventCount: number;
        }>;
        list(authority: HostAuthority): Promise<{
            ok: false;
            code: import("./types.js").ErrorCode;
            message: string;
        } | {
            ok: true;
            value: {
                id: string;
                state: string;
                eventCount: any;
                hasSummary: boolean;
            }[];
        }>;
        get(authority: HostAuthority, candidateId: string, options?: import("./summarizer.js").SummaryContext): Promise<{
            ok: false;
            code: import("./types.js").ErrorCode;
            message: string;
        } | {
            ok: true;
            value: import("./candidates.js").MemoryCandidate;
        }>;
        adopt(authority: HostAuthority, controlSource: import("./types.js").SourceRevision, candidateId: string, options: import("./summarizer.js").PublishContext): Promise<import("./types.js").Result<import("./summarizer.js").AdoptionResult>>;
        reject(authority: HostAuthority, controlSource: import("./types.js").SourceRevision, candidateId: string, key: string): Promise<import("./types.js").Result<{
            alreadyDecided: boolean;
        }>>;
    };
    jobs: {
        nativeStatus: () => {
            enabled: boolean;
            status: string;
            code: string;
            actualModelCalls: number;
        };
        runNative: () => Promise<import("./types.js").Result<never>>;
        list(authority: HostAuthority): Promise<{
            ok: false;
            code: import("./types.js").ErrorCode;
            message: string;
        } | {
            ok: true;
            value: readonly import("./types.js").Job[];
        }>;
        enqueue(authority: HostAuthority, selection: import("./candidates.js").SummarySelection, options: import("./summarizer.js").SummaryContext & {
            idempotencyKey: string;
        }): Promise<import("./types.js").Result<import("./types.js").Job>>;
        recover(authority: HostAuthority): Promise<{
            ok: false;
            code: import("./types.js").ErrorCode;
            message: string;
        } | {
            ok: true;
            value: readonly import("./types.js").Job[];
        }>;
        run(authority: HostAuthority, id: string, generator: import("./jobs.js").CandidateGenerator, options: import("./jobs.js").RunOptions): Promise<import("./types.js").Result<import("./types.js").Summary>>;
        close(): Promise<void>;
    };
    retrieval: Readonly<{
        search(authority: HostAuthority, input: {
            query?: string;
            cursor?: string;
            limit?: number;
            entityId?: string;
            kind?: string;
        }): Promise<{
            ok: false;
            code: import("./types.js").ErrorCode;
            message: string;
        } | {
            ok: true;
            value: {
                snapshotId: string;
                queryHash: string;
                resultManifestHash: string;
                sortVersion: string;
                items: {
                    id: string;
                    revision: string;
                    kind: "source" | "event" | "summary" | "state";
                    excerpt: string;
                }[];
                nextCursor: string | null;
            };
        }>;
        get(authority: HostAuthority, input: {
            id?: string;
            cursor?: string;
            maxChars?: number;
        }): Promise<{
            ok: false;
            code: import("./types.js").ErrorCode;
            message: string;
        } | {
            ok: true;
            value: {
                recordId: string;
                revision: string;
                snapshotId: string;
                bodySha256: string;
                text: string;
                nextCursor: string | null;
                currentStatus: {
                    verification: "source-match" | "unavailable" | "hash-mismatch";
                    revoked: boolean;
                };
            };
        }>;
        dispose(): void;
    }>;
    packets: Readonly<{
        prepare(authority: HostAuthority, input: {
            budget: import("./packet.js").RuntimeBudget;
            globalAuthorities: readonly object[];
            inputBindings: readonly import("./packet.js").InputBinding[];
            optionalTokens?: number;
            personId?: string;
            runtime?: import("./modules/runtime.js").ModuleContext;
        }): Promise<import("./types.js").Result<import("./packet.js").MemoryPacket>>;
        admit(authority: HostAuthority, packet: import("./packet.js").MemoryPacket, request: Record<string, unknown>): Promise<{
            ok: false;
            code: import("./types.js").ErrorCode;
            message: string;
        } | {
            ok: true;
            value: {
                packetId: string;
                inputTokens: number;
                reserve: number;
                effective: number;
                totalTokens: number;
                mode: "estimated";
                limited: boolean;
            };
        }>;
    }>;
    coordinator: MemoryCoordinator;
    registerInputBindings(branchId: string, bindings: readonly import("./packet.js").InputBinding[]): void;
    modules: Readonly<{
        registry: readonly import("./modules/contract.js").ModuleManifest[];
        create(authority: HostAuthority, config?: unknown, active?: () => boolean): Readonly<{
            binding: () => import("./modules/contract.js").RuntimeBinding;
            context: () => import("./modules/runtime.js").ModuleContext;
            revoke: () => void;
            run(moduleId: string, input: unknown, key?: string): Promise<{
                value: unknown;
            }>;
            verify(result: object): Promise<import("./modules/runtime.js").ModuleReceipt>;
        }>;
    }>;
    management: Readonly<{
        create(authority: HostAuthority, active?: () => boolean): Readonly<{
            revoke(): void;
            snapshot(): Promise<{
                candidates: {
                    state: any;
                    protocol: "person-growth/v1";
                    id: string;
                    inputFence: import("./types.js").InputFence;
                    changes: ({
                        changeId: string;
                        personId: string;
                        fieldId: string;
                        previousEventId: string | null;
                        previousChangeId?: string;
                        value: string;
                        causeEventIds: string[];
                        note: string;
                    } & {
                        eventId: string;
                    })[];
                }[];
                timelines: {
                    changes: {
                        eventId: string;
                        acceptedSeq: number;
                        fictionalTime: string | null;
                        sourceRevisionIds: string[];
                        current: boolean;
                        expired: boolean;
                        protocol: "person-core/v1";
                        operation: "init" | "edit" | "grow" | "set-policy";
                        previousEventId: string | null;
                        causeEventIds: string[];
                        note: string;
                        fieldId: string;
                        kind: import("./person/types.js").PersonFieldKind;
                        value: string;
                        policy: import("./person/types.js").PersonPolicy;
                        validity?: import("./person/types.js").PersonValidity;
                    }[];
                    changeCount: number;
                    personId: string;
                    fence: import("./types.js").InputFence;
                    originEventId: string;
                    invalidatedEventIds: string[];
                }[];
                notice: string;
                fence: import("./types.js").InputFence;
                persons: {
                    personId: string;
                    originEventId: string;
                    fence: import("./types.js").InputFence;
                    fields: {
                        eventId: string;
                        protocol: "person-core/v1";
                        operation: "init" | "edit" | "grow" | "set-policy";
                        previousEventId: string | null;
                        causeEventIds: string[];
                        note: string;
                        fieldId: string;
                        kind: import("./person/types.js").PersonFieldKind;
                        value: string;
                        policy: import("./person/types.js").PersonPolicy;
                        validity?: import("./person/types.js").PersonValidity;
                    }[];
                    relationships: import("./types.js").RelationshipProjection[];
                    goals: import("./types.js").StateProjection[];
                }[];
                experiences: import("./types.js").SemanticEvent[];
                experienceCount: number;
                id: string;
                entityIds: string[];
            }>;
            prepare(input: unknown): Promise<{
                id: string;
                action: string;
                payload: any;
                fence: import("./types.js").InputFence;
                notice: string;
            }>;
            confirm(id: string): Promise<unknown>;
        }>;
    }>;
    adoptCanon(authority: HostAuthority, globalAuthority: object, approval: object, publicationId: string, key: string): Promise<import("./types.js").Result<import("./types.js").InputFence>>;
}>;
