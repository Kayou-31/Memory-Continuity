import type { RpStore } from './store.js';
import type { HostAuthority, Result, SourceRevision } from './types.js';
export declare const fullSpan: (s: SourceRevision) => {
    sourceRevisionId: string;
    publicTextSha256: string;
    startUtf16: number;
    endUtf16: number;
    quoteSha256: string;
};
export declare function unwrap<T>(r: Result<T>): T;
export declare function createRetrieval(store: RpStore, options?: {
    inputSourceIds?: (authority: HostAuthority) => ReadonlySet<string>;
    entityIds?: readonly string[];
    verification?: (recordId: string) => Promise<'source-match' | 'unavailable' | 'hash-mismatch'>;
}): Readonly<{
    search(authority: HostAuthority, input: {
        query?: string;
        cursor?: string;
        limit?: number;
        entityId?: string;
        kind?: string;
    }): Promise<{
        ok: false;
        code: import("./types.js").ErrorCode;
        message: string;
    } | {
        ok: true;
        value: {
            snapshotId: string;
            queryHash: string;
            resultManifestHash: string;
            sortVersion: string;
            items: {
                id: string;
                revision: string;
                kind: "source" | "event" | "summary" | "state";
                excerpt: string;
            }[];
            nextCursor: string | null;
        };
    }>;
    get(authority: HostAuthority, input: {
        id?: string;
        cursor?: string;
        maxChars?: number;
    }): Promise<{
        ok: false;
        code: import("./types.js").ErrorCode;
        message: string;
    } | {
        ok: true;
        value: {
            recordId: string;
            revision: string;
            snapshotId: string;
            bodySha256: string;
            text: string;
            nextCursor: string | null;
            currentStatus: {
                verification: "source-match" | "unavailable" | "hash-mismatch";
                revoked: boolean;
            };
        };
    }>;
    dispose(): void;
}>;
