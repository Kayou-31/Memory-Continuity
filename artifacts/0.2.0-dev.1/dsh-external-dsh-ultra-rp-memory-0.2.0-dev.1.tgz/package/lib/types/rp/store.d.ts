import type { Branch, CommitBatch, HostAuthority, InputFence, Job, LedgerSnapshot, Result, SemanticEvent, SourceObservation, SourceRevision, SourceSpan, Summary, Visibility, Viewpoint, WorkspaceBinding, AuthorityChange, CanonBinding, ForkManifest, PayloadCopy, PrivacyDeletion, ProjectionResult } from './types.js';
export { parseRecord } from './schema.js';
/** Trusted storage adapters reuse the same verified lock/read protocol. */
export { lock as withRpWriterLock, recoverLock as recoverRpWriterLock, readJson as readRpJson };
export type * from './types.js';
/** Order-independent object keys, order-preserving arrays; used for effects and chains. */
export declare function canonical(value: unknown): string;
type Permission = 'read' | 'observe' | 'commit' | 'control';
export type FaultStage = 'profile_locked' | 'metadata_listed' | 'blob_written' | 'blob_synced' | 'blob_published' | 'transaction_written' | 'transaction_synced' | 'transaction_published' | 'seal_written' | 'seal_synced' | 'seal_published' | 'directory_synced';
export interface StoreOptions {
    readonly profileRoot: string;
    /** Trusted filesystem fault seam; never supplied by model/tool input. */
    readonly fault?: (stage: FaultStage) => void | Promise<void>;
    readonly onBlobRead?: () => void;
    /** Later global-store adapter validates exact approved publication bindings. */
    readonly verifyCanonBinding?: (record: CanonBinding) => Promise<boolean>;
    /** Trusted fault/diagnostic seams. Called only after the tombstone is sealed. */
    readonly beforePurge?: () => void | Promise<void>;
    readonly onPurge?: (blobId: string) => void;
}
export interface AuthorityRequest {
    readonly workspaceId: string;
    readonly campaignId: string;
    readonly branchId: string;
    readonly sessionId?: string;
    readonly sceneId?: string;
    readonly viewpoint: Viewpoint;
    readonly visibility: Visibility;
    readonly audienceSetIds: readonly string[];
    readonly permissions: readonly Permission[];
}
/** Operation-local data; readSource closes when the callback settles. */
export interface RpReadView {
    readonly context: {
        readonly sceneId?: string;
        readonly acceptedSeq: number;
    };
    readonly fence: InputFence;
    readonly events: readonly SemanticEvent[];
    readonly summaries: readonly Summary[];
    readonly projection: ProjectionResult;
    readonly sources: readonly SourceRevision[];
    readonly ledger: LedgerSnapshot | null;
    readSource(span: SourceSpan): Promise<string>;
}
interface DirectoryIdentity {
    readonly dev: string;
    readonly ino: string;
    readonly birthtime: string;
}
declare function readJson(file: string, max?: number): Promise<unknown>;
declare function lock<T>(directory: string, work: () => Promise<T>): Promise<T>;
/** Caller is a trusted host control. Never accept paths from model tools. */
declare function recoverLock(directory: string): Promise<'recovered' | 'unlocked'>;
export declare class RpStore {
    #private;
    constructor(options: StoreOptions, root: string, profileRoot: string, profileId: string, profileIdentity: DirectoryIdentity);
    /** Only platform-level durability evidence; a successful file fsync is not a power-loss guarantee. */
    durability(): {
        fileSync: 'required';
        directorySync: 'supported' | 'unsupported' | 'unverified';
        powerLossVerified: false;
    };
    /** Upper-level idempotent acknowledgements must finish the same seal protocol. */
    ensureDurable(authority: HostAuthority, expected: InputFence): Promise<Result<InputFence>>;
    readBranch(authority: HostAuthority): Promise<Result<Branch>>;
    readFence(authority: HostAuthority): Promise<Result<InputFence>>;
    readControlCommit(authority: HostAuthority, inputKey: string): Promise<Result<{
        readonly fence: InputFence;
        readonly authorityChanges: readonly AuthorityChange[];
    } | null>>;
    readLedger(authority: HostAuthority): Promise<Result<LedgerSnapshot>>;
    /** Two verified loads bracket the whole assembly, without retaining any view
     * across requests, authorities, revisions or privacy generations. */
    withReadView<T>(authority: HostAuthority, work: (view: RpReadView) => Promise<T> | T, options?: {
        audit?: boolean;
    }): Promise<Result<T>>;
    readSource(authority: HostAuthority, input: SourceSpan): Promise<Result<string>>;
    /** Public discovery authorizes each source before returning IDs or counts.
     * Unlike readLedger, this does not expose hidden control/deletion metadata. */
    readAcceptedSources(authority: HostAuthority): Promise<Result<readonly SourceRevision[]>>;
    sourceSpan(authority: HostAuthority, sourceId: string, startUtf16: number, endUtf16: number): Promise<Result<SourceSpan>>;
    openSourceSnapshot(authority: HostAuthority, span: SourceSpan): Promise<Result<object>>;
    readSourcePage(authority: HostAuthority, snapshot: object, offset: number, limit: number): Promise<Result<{
        snapshotId: string;
        bodySha256: string;
        text: string;
        nextOffset: number | null;
    }>>;
    replayProjection(authority: HostAuthority): Promise<Result<ProjectionResult>>;
    readEvents(authority: HostAuthority): Promise<Result<readonly SemanticEvent[]>>;
    readSummaries(authority: HostAuthority): Promise<Result<readonly Summary[]>>;
    savePayloadCopy(authority: HostAuthority, input: {
        readonly idempotencyKey: string;
        readonly id: string;
        readonly kind: PayloadCopy['kind'];
        readonly sourceRevisionIds: readonly string[];
        readonly dependencyIds: readonly string[];
        readonly body: string;
    }): Promise<Result<PayloadCopy>>;
    readPayloadCopies(authority: HostAuthority): Promise<Result<readonly (PayloadCopy & {
        readonly body: string;
    })[]>>;
    observeSource(authority: HostAuthority, input: SourceObservation): Promise<Result<SourceRevision>>;
    /** Job metadata belongs to this same sealed authority log, but is not story input. */
    transitionJob(authority: HostAuthority, input: {
        readonly idempotencyKey: string;
        readonly expected: Job | null;
        readonly next: Job;
    }): Promise<Result<Job>>;
    commit(authority: HostAuthority, input: CommitBatch): Promise<Result<InputFence>>;
    forkManifest(authority: HostAuthority, revision: number): Promise<Result<ForkManifest>>;
    /** Internal trusted-host API: never register these methods as model tools. */
    hostControl(): Readonly<{
        forkBranch: (authority: HostAuthority, input: ForkManifest & {
            readonly idempotencyKey: string;
        }) => Promise<Result<Branch>>;
        privacyDelete: (authority: HostAuthority, controlSourceId: string, input: {
            readonly idempotencyKey: string;
            readonly expected: InputFence;
            readonly sourceRevisionIds: readonly string[];
            readonly affectedBranchIds: readonly string[];
        }, authorities: readonly HostAuthority[]) => Promise<Result<PrivacyDeletion>>;
        purgePrivacy: (authority: HostAuthority, key: string, authorities?: readonly HostAuthority[]) => Promise<Result<PrivacyDeletion>>;
        createWorkspace: (inputRoot: string) => Promise<Result<WorkspaceBinding>>;
        openWorkspace: (root: string) => Promise<Result<WorkspaceBinding>>;
        migrateWorkspace: (authority: HostAuthority, inputRoot: string) => Promise<Result<WorkspaceBinding>>;
        createBranch: (workspaceId: string, campaignId: string) => Promise<Result<Branch>>;
        authorize: (input: AuthorityRequest) => Promise<Result<HostAuthority>>;
        recoverWriterLock: (authority: HostAuthority) => Promise<Result<"recovered" | "unlocked">>;
    }>;
}
/** Trusted host bootstrap. profileRoot is resolved by the host, never by tools. */
export declare function openRpStore(input: StoreOptions): Promise<{
    store: RpStore;
    control: ReturnType<RpStore['hostControl']>;
}>;
/** Trusted bootstrap recovery for a profile-root lock, available before open.
 * Existing profile/directory identity must match; no timeout-based stealing. */
export declare function recoverRpProfileLock(input: {
    readonly profileRoot: string;
}): Promise<Result<'recovered' | 'unlocked'>>;
