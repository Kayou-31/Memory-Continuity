/** Pure reconstruction from already authorized, active events. No model, clock,
 * filesystem, implicit co-presence knowledge or last-timestamp conflict winner. */
import type { ClaimAssessment, InputFence, JsonValue, ProjectionResult, SemanticEvent, Viewpoint } from './types.js';
export declare function reduceEvents(input: readonly SemanticEvent[], fence: InputFence, context?: {
    sceneId?: string;
    acceptedSeq: number;
}): ProjectionResult;
export declare function assessClaim(projection: Pick<ProjectionResult, 'state'>, query: {
    readonly subjectId: string;
    readonly key: string;
    readonly value: JsonValue;
    readonly epistemic: SemanticEvent['epistemic'];
    readonly beliefHolderId?: string;
}): ClaimAssessment;
export declare function eventsForView(events: readonly SemanticEvent[], fence: InputFence, view: Viewpoint): readonly SemanticEvent[];
