import { type RpStore } from './store.js';
import type { createCanonicalService } from './canonical.js';
import type { HostAuthority, InputFence, JsonValue, SourceRevision } from './types.js';
import { type GoalValue } from './growth-format.js';
type Base = {
    idempotencyKey: string;
    expected: InputFence;
    fictionalTime?: string | null;
};
type Progress = {
    previousEventId: string | null;
    causeEventIds: string[];
    note: string;
    value: JsonValue;
};
export type AgentMemoryControl = Base & ({
    kind: 'experience';
    actorIds: string[];
    description: string;
    sourceRevisionIds: string[];
} | (Progress & {
    kind: 'state';
    entityId: string;
    key: string;
}) | (Progress & {
    kind: 'relationship';
    fromId: string;
    toId: string;
    relation: string;
}) | (Omit<Progress, 'value'> & GoalValue & {
    kind: 'goal';
    ownerId: string;
}));
export declare function createAgentMemory(store: RpStore, service: ReturnType<typeof createCanonicalService>, entityIds: readonly string[]): Readonly<{
    apply(authority: HostAuthority, controlSource: SourceRevision, input: AgentMemoryControl): Promise<{
        readonly ok: false;
        readonly code: import("./types.js").ErrorCode;
        readonly message: string;
    } | {
        ok: true;
        value: {
            eventId: string;
            fence: InputFence;
        };
    }>;
}>;
export {};
