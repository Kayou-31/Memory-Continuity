/** Process-local capabilities. No serialized value is an owner or a request ticket. */
export declare const RP_ADMISSION = "dsh.rp-admission/v1";
export type BindingStamp = Readonly<{
    epoch: number;
    generation: number;
    active: boolean;
}>;
export declare class RpAdmission {
    readonly protocol = "dsh.rp-admission/v1";
    private owners;
    private bindings;
    private tickets;
    private installation?;
    createOwner(): Readonly<{}>;
    reserve(owner: object): void;
    unreserve(owner: object): void;
    bind(owner: object, session: string, live: () => BindingStamp): void;
    retire(owner: object): void;
    retireBinding(owner: object, session: string): void;
    has(session: string): boolean;
    release(owner: object, session: string): void;
    issue(owner: object, session: string, options: object, stamp: BindingStamp): () => void;
    permits(session: string, options: object): boolean;
}
export declare function acquireRpAdmission(root: {
    get(key: string): any;
    provide?(key: string, value: unknown): unknown;
}): RpAdmission;
