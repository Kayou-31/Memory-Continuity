import type { RpStore } from './store.js';
import type { EventPayload, ForkManifest, HostAuthority, InputFence, Result, SemanticEvent, SourceRevision } from './types.js';
export { assessClaim, reduceEvents } from './reducer.js';
export { applyNativeCanonicalEvent } from './host-adapter.js';
export interface EventProposal {
    readonly id: string;
    readonly payload: EventPayload;
    readonly epistemic: SemanticEvent['epistemic'];
    readonly beliefHolderId?: string;
    readonly fictionalTime?: string | null;
    readonly sourceRevisionIds?: readonly string[];
    readonly supersedes?: readonly string[];
    readonly growthProtocol?: 'agent-memory/v1';
    readonly personProtocol?: 'person-core/v1' | 'person-origin/v1';
}
type BaseControl = {
    readonly idempotencyKey: string;
    readonly expected: InputFence;
};
export type CanonicalControl = BaseControl & ({
    readonly kind: 'accept' | 'confirm_replay';
    readonly sourceRevisionIds: readonly string[];
    readonly events: readonly EventProposal[];
    readonly personCandidates?: readonly {
        candidateId: string;
        eventIds: readonly string[];
        decision: 'accepted' | 'rejected';
    }[];
} | {
    readonly kind: 'reject' | 'retract';
    readonly sourceRevisionIds: readonly string[];
} | {
    readonly kind: 'replace';
    readonly sourceRevisionId: string;
    readonly replacementSourceRevisionId: string;
    readonly events: readonly EventProposal[];
} | {
    readonly kind: 'retcon';
    readonly targetEventIds: readonly string[];
    readonly events: readonly EventProposal[];
} | {
    readonly kind: 'character_forget';
    readonly knowerId: string;
    readonly claimId: string;
} | {
    readonly kind: 'privacy_delete';
    readonly sourceRevisionIds: readonly string[];
    readonly affectedBranchIds: readonly string[];
});
export declare function createCanonicalService(store: RpStore, control: ReturnType<RpStore['hostControl']>, options: {
    readonly entityIds: readonly string[];
}): Readonly<{
    forkManifest: (authority: HostAuthority, revision: number) => Promise<Result<ForkManifest>>;
    forkBranch: (authority: HostAuthority, manifest: ForkManifest & {
        readonly idempotencyKey: string;
    }) => Promise<Result<import("./types.js").Branch>>;
    resumePrivacyDelete: (authority: HostAuthority, key: string, affectedAuthorities?: readonly HostAuthority[]) => Promise<Result<import("./types.js").PrivacyDeletion>>;
    applyCanonicalChange(change: CanonicalControl, authority: HostAuthority, userControlSource: SourceRevision): Promise<{
        readonly ok: false;
        readonly code: import("./types.js").ErrorCode;
        readonly message: string;
    } | {
        readonly ok: true;
        readonly value: InputFence;
    } | {
        readonly ok: true;
        readonly value: import("./types.js").PrivacyDeletion;
    }>;
    applyControl(authority: HostAuthority, userControlSource: SourceRevision, input: CanonicalControl, affectedAuthorities?: readonly HostAuthority[]): Promise<{
        readonly ok: false;
        readonly code: import("./types.js").ErrorCode;
        readonly message: string;
    } | {
        readonly ok: true;
        readonly value: InputFence;
    } | {
        readonly ok: true;
        readonly value: import("./types.js").PrivacyDeletion;
    }>;
}>;
