export declare const SEGMENT_FORMAT = "rp.global-segments/v1";
export declare const SEGMENT_PUBLISH_BYTES: number, SEGMENT_CONTROL_BYTES: number;
export interface SegmentLayout {
    backupId: string;
    backupSha256: string;
}
interface State {
    fence: unknown;
    publications: unknown[];
    keys: Record<string, unknown>;
    previousHash: string;
    seq: number;
}
type Atomic = (file: string, body: string) => Promise<void>;
export declare function readSegmentState(dir: string, input: unknown, cache: Map<string, unknown>): Promise<{
    state: State;
    sha256: string;
    layout: SegmentLayout;
}>;
export declare function encodeSegments(state: State, layout: SegmentLayout): {
    encoded: string;
    pages: Map<string, string>;
};
export declare function writeSegments(dir: string, pages: Map<string, string>, atomic: Atomic): Promise<void>;
export declare function backupGlobal(root: string, dir: string, state: State, atomic: Atomic): Promise<SegmentLayout>;
export {};
