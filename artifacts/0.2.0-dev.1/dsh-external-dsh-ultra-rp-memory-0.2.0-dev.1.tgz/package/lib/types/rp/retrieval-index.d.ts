import type { RpStore } from './store.js';
import type { HostAuthority, SemanticEvent, InputFence } from './types.js';
export interface RetrievalRecord {
    id: string;
    revision: string;
    body: string;
    kind: 'source' | 'event' | 'summary' | 'state';
    entities: readonly string[];
}
export declare function eventEntities(e: SemanticEvent): string[];
export declare function authorizedRecords(store: RpStore, authority: HostAuthority, inputSourceIds: ReadonlySet<string>): Promise<RetrievalRecord[]>;
export interface RetrievalView {
    fence: InputFence;
    records: RetrievalRecord[];
}
export declare function readConsistentRecords(store: RpStore, authority: HostAuthority, inputSourceIds: ReadonlySet<string>): Promise<RetrievalView>;
