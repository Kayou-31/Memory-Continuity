import { type RuntimeBinding } from './modules/contract.js';
import { type PersonBinding } from './person/binding.js';
import type { AuthorityRequest } from './store.js';
import type { InputBinding, GlobalDependency } from './packet.js';
import type { InputFence } from './types.js';
import type { GlobalFence } from './global.js';
import type { RetrievalRecordRef } from './retrieval-evidence.js';
import { type PacketProof } from './packet-proof.js';
export interface Snapshot {
    runtimeBinding?: RuntimeBinding;
    personBinding?: PersonBinding;
    provenance?: 'packet' | 'tool-call' | 'retrieval-result' | 'status' | 'error';
    packetProof?: PacketProof;
    records?: readonly RetrievalRecordRef[];
    resultSha256?: string;
    messageId?: string;
    bodyHash: string;
    packetId: string;
    fence: InputFence;
    globals: GlobalFence[];
    globalDependencies: GlobalDependency[];
    globalPolicyHash: string;
    dependencyIds: string[];
    eventIds: string[];
    modeEpoch: number;
}
export interface Input extends InputBinding {
    dispatched: boolean;
    bodyHash: string;
    phase: 'observed' | 'accepted' | 'dispatching' | 'dispatched';
    operationKey: string;
    expected: InputFence;
}
export interface DurableSession {
    runtimeBinding?: RuntimeBinding;
    personBinding?: PersonBinding;
    schemaVersion: 1 | 2;
    sessionId: string;
    request: AuthorityRequest;
    inputs: Input[];
    hostSources: Record<string, string>;
    snapshots: Record<string, Snapshot>;
    frames: Record<string, Snapshot>;
    receipts: Record<string, {
        contentHash: string;
        snapshot: Snapshot;
    }>;
    pending: Record<string, Snapshot>;
    messageHashes: Record<string, string>;
    currentTurnId?: string;
    blocked?: boolean;
}
export declare function validateJournal(input: unknown): DurableSession;
