import { type RpStore } from './store.js';
import type { HostAuthority, Job, Result, SourceRevision, Summary } from './types.js';
import type { SummarySelection } from './candidates.js';
import type { SummaryContext, SummaryService } from './summarizer.js';
import type { MemoryCoordinator } from './session-policy.js';
/** Trusted injected generators must cooperate with cancellation and close their
 * own streams before settling. A slot remains held until actual settlement. */
export interface CandidateGenerator {
    generate(input: ReturnType<SummaryService['generatorInput']>, signal: AbortSignal): Promise<unknown>;
}
export interface RunOptions extends SummaryContext {
    controlSource: SourceRevision;
    signal?: AbortSignal;
    /** Requests abort; not a hard completion deadline for an uncooperative generator. */
    timeoutMs?: number;
    retryStale?: boolean;
}
export declare function createJobService(input: {
    store: RpStore;
    summaries: SummaryService;
    coordinator: MemoryCoordinator;
    profileKey: string;
}): {
    nativeStatus: () => {
        enabled: boolean;
        status: string;
        code: string;
        actualModelCalls: number;
    };
    runNative: () => Promise<Result<never>>;
    list(authority: HostAuthority): Promise<{
        ok: false;
        code: import("./types.js").ErrorCode;
        message: string;
    } | {
        ok: true;
        value: readonly Job[];
    }>;
    enqueue(authority: HostAuthority, selection: SummarySelection, options: SummaryContext & {
        idempotencyKey: string;
    }): Promise<Result<Job>>;
    recover(authority: HostAuthority): Promise<{
        ok: false;
        code: import("./types.js").ErrorCode;
        message: string;
    } | {
        ok: true;
        value: readonly Job[];
    }>;
    run(authority: HostAuthority, id: string, generator: CandidateGenerator, options: RunOptions): Promise<Result<Summary>>;
    close(): Promise<void>;
};
