import type { Result, RpRecord, CommitBatch, SourceObservation, SourceSpan, Scope, Visibility, EventPayload, SemanticEvent, Summary, Branch, BranchSourceBinding, InputFence, Job, AuthorityChange } from './types.js';
export declare class RpError extends Error {
    readonly code: import('./types.js').ErrorCode;
    constructor(code: import('./types.js').ErrorCode, message: string);
}
export declare function invalid(field: string): never;
export declare function denied(field: string): never;
export declare function wellFormed(v: string): boolean;
export declare function object(v: unknown, required: readonly string[], optional?: readonly string[]): Record<string, any>;
export declare function text(v: unknown, max?: number, empty?: boolean): asserts v is string;
export declare function id(v: unknown): asserts v is string;
/** SDK UUID identities may start with a digit; they are never filesystem paths. */
export declare function hostId(v: unknown): asserts v is string;
export declare function hash(v: unknown): asserts v is string;
export declare function integer(v: unknown, min?: number): asserts v is number;
export declare const MAX_EXACT_ANCHORS = 256;
export declare function scope(v: unknown): asserts v is Scope;
export declare function visibility(v: unknown): asserts v is Visibility;
export declare function fence(v: unknown): asserts v is InputFence;
export declare function sourceSpan(v: unknown): asserts v is SourceSpan;
export declare function binding(v: unknown): asserts v is BranchSourceBinding;
export declare function payload(v: unknown): asserts v is EventPayload;
export declare function event(v: unknown): asserts v is SemanticEvent;
export declare function summary(v: unknown): asserts v is Summary;
export declare function branch(v: unknown): asserts v is Branch;
export declare function job(v: unknown): asserts v is Job;
export declare function authorityChange(v: unknown): asserts v is AuthorityChange;
export declare function batch(v: unknown): asserts v is CommitBatch;
export declare function observation(v: unknown): asserts v is SourceObservation;
/** Before serialization: bounded recursive inspection rejects lossy values and accessors. */
export declare const MAX_RP_JSON_BYTES = 4194304;
export declare const MAX_RP_PUBLISH_BYTES = 3145728;
export declare function cloneInput<T>(input: T, maxBytes?: number, capacityError?: boolean, maxArrayLength?: number): T;
/** Inspect the entire envelope, then write exactly these preflighted bytes. */
export declare function checkedRpJson(input: unknown, encode: (value: unknown) => string, maxBytes?: number, maxArrayLength?: number): string;
export declare function parseRecord(input: unknown): Result<RpRecord>;
export declare function failure(error: unknown): {
    ok: false;
    code: import('./types.js').ErrorCode;
    message: string;
};
