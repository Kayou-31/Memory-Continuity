import type { RpStore } from './store.js';
import { type CandidateSnapshot, type MemoryCandidate, type SummarySelection } from './candidates.js';
import type { HostAuthority, Job, SemanticEvent, SourceRevision, Summary, Result } from './types.js';
import type { openRpGlobalStore } from './global.js';
import { MemoryCoordinator } from './session-policy.js';
export interface SummaryContext {
    globalAuthorities?: readonly object[];
    policyEpoch?: () => number;
}
export interface PublishContext extends SummaryContext {
    idempotencyKey: string;
    job?: Job;
    signal?: AbortSignal;
}
export interface AdoptionResult {
    alreadyDecided: boolean;
    events?: readonly SemanticEvent[];
    summary?: Summary;
}
export declare function createSummaryService(input: {
    store: RpStore;
    global: Awaited<ReturnType<typeof openRpGlobalStore>>;
    coordinator: MemoryCoordinator;
    entityIds: readonly string[];
}): {
    capture: (authority: HostAuthority, raw: SummarySelection, options?: SummaryContext) => Promise<CandidateSnapshot>;
    guard: (authority: HostAuthority, snapshot: Pick<CandidateSnapshot, "inputFence" | "globalFences" | "policyEpoch">, options: SummaryContext) => Promise<void>;
    generatorInput: (snapshot: CandidateSnapshot) => {
        schemaVersion: number;
        level: "scene" | "chapter" | "arc";
        inputFence: import("./types.js").InputFence;
        sources: {
            id: string;
            text: string;
            span: {
                sourceRevisionId: string;
                publicTextSha256: string;
                startUtf16: number;
                endUtf16: number;
                quoteSha256: string;
            };
        }[];
        childSummaries: readonly Summary[];
        supportEvents: readonly SemanticEvent[];
        entityIds: readonly string[];
        boundary: "explicit" | "proposal";
        rules: string;
    };
    propose(authority: HostAuthority, raw: unknown, selection: SummarySelection, options?: SummaryContext): Promise<{
        ok: false;
        code: import("./types.js").ErrorCode;
        message: string;
    } | {
        ok: true;
        value: {
            id: string;
            state: "pending";
            inputFence: import("./types.js").InputFence;
            hasSummary: boolean;
            eventCount: number;
        };
    }>;
    fromGenerated(authority: HostAuthority, raw: unknown, snapshot: CandidateSnapshot, options?: SummaryContext): Promise<{
        id: string;
        state: "pending";
        inputFence: import("./types.js").InputFence;
        hasSummary: boolean;
        eventCount: number;
    }>;
    list(authority: HostAuthority): Promise<{
        ok: false;
        code: import("./types.js").ErrorCode;
        message: string;
    } | {
        ok: true;
        value: {
            id: string;
            state: string;
            eventCount: any;
            hasSummary: boolean;
        }[];
    }>;
    get(authority: HostAuthority, candidateId: string, options?: SummaryContext): Promise<{
        ok: false;
        code: import("./types.js").ErrorCode;
        message: string;
    } | {
        ok: true;
        value: MemoryCandidate;
    }>;
    adopt(authority: HostAuthority, controlSource: SourceRevision, candidateId: string, options: PublishContext): Promise<Result<AdoptionResult>>;
    reject(authority: HostAuthority, controlSource: SourceRevision, candidateId: string, key: string): Promise<Result<{
        alreadyDecided: boolean;
    }>>;
};
export type SummaryService = ReturnType<typeof createSummaryService>;
