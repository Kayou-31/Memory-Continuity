/** RP application capability gates. These names are not DSH native APIs.
 * A structurally valid report is evidence metadata, not an authorization from
 * a model or an arbitrary caller. Production must use its own pinned probe.
 */
export declare const capabilityKeys: readonly ["canonicalReplySelection", "messageRevisions", "forkLineage", "requestInjection", "requestContextFiltering", "durableSurfaceReplacement", "lifecycleRecovery", "tokenAccounting", "exclusiveCompactionOwnership", "modelInvocation", "uiIntegration"];
export type CapabilityKey = typeof capabilityKeys[number];
export type CapabilityStatus = 'verified' | 'unsupported' | 'failed' | 'unverified';
export type ProductMode = 'capture' | 'memory' | 'compaction';
export interface CapabilityResult {
    readonly status: CapabilityStatus;
    readonly probe: string | null;
    readonly evidence: readonly string[];
    readonly contract: string | null;
}
export interface CapabilityReport {
    readonly schemaVersion: 1;
    readonly baselineCommit: string;
    readonly host: {
        readonly packageVersions: Readonly<Record<string, string>>;
        readonly sessionHeaderVersion: number | null;
    };
    readonly evidenceRoot: string | null;
    readonly capabilities: Readonly<Record<CapabilityKey, CapabilityResult>>;
    readonly allowedModes: readonly ProductMode[];
    readonly limitations: readonly string[];
}
export declare class CapabilityReportError extends TypeError {
    readonly code = "invalid_capability_report";
}
export declare class CapabilityMissingError extends Error {
    readonly missing: readonly (CapabilityKey | RpReadinessKey)[];
    readonly code = "capability_missing";
    constructor(missing: readonly (CapabilityKey | RpReadinessKey)[]);
}
export type RpReadinessKey = 'sourceObservation' | 'effectiveHistory' | 'revisionFence' | 'branchIsolation';
export type RpReadinessProof = Readonly<Partial<Record<RpReadinessKey, string>>>;
declare const readinessBrand: unique symbol;
export interface RpReadiness {
    readonly [readinessBrand]: true;
}
/** Internal adapter seam: trusted store/adapter code binds a live verifier.
 * The verifier must read its own current validated state on EVERY admission.
 * Do not expose this function to tools/model inputs or bind parsed JSON.
 * The non-serializable handle cannot be minted by a model-supplied boolean.
 */
export declare function bindRpReadiness(verify: () => RpReadinessProof): RpReadiness;
export declare function deriveAllowedModes(capabilities: Readonly<Record<CapabilityKey, CapabilityResult>>): ProductMode[];
/** Bounded strict schema parse; derived grants must match supplied metadata. */
export declare function parseCapabilityReport(input: unknown): CapabilityReport;
export interface RpCapabilityRequest {
    readonly mode: ProductMode;
    readonly strictPov?: boolean;
    readonly automaticCanonical?: boolean;
    readonly modelExtraction?: boolean;
}
/** Fail before dispatch. No caller-supplied report can override missing gates. */
export declare function assertRpCapabilities(input: CapabilityReport, request: RpCapabilityRequest, readiness?: RpReadiness): void;
/** Capability discovery only; this does not select or replace a surface range. */
export declare function inspectRpCompressionBoundary(report: CapabilityReport, boundary: {
    unreadableMultimodal: boolean;
    toolPairsComplete: boolean;
}, readiness?: RpReadiness): {
    eligible: boolean;
    reasons: string[];
};
export {};
