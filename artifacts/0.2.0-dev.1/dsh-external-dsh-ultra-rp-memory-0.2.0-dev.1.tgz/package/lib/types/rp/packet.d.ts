import { type ModuleContext } from './modules/runtime.js';
import type { HostAuthority, InputFence, Result } from './types.js';
import type { RpStore } from './store.js';
import type { openRpGlobalStore, GlobalFence } from './global.js';
import { type PacketProof } from './packet-proof.js';
import type { RecallOptimizer } from './memory-optimizer.js';
export interface RuntimeBudget {
    recentCompleteTurns: number;
    targetTotalTokens: number;
    triggerTotalTokens: number;
    outputReserveTokens: number;
    toolReserveTokens: number;
    packetSoftTokens: number;
    contextWindow: number;
    inputLimit: number;
}
/** Trusted driver bindings distinguish accepted story input from OOC controls. */
export interface InputBinding {
    kind: 'input';
    sourceId: string;
    turnId: string;
    messageId: string;
}
export interface GlobalDependency {
    publicationId: string;
    sourceId: string;
    bodySha256: string;
    scope: GlobalFence['scope'];
    key: string;
}
export interface MemoryPacket {
    id: string;
    inputFence: InputFence;
    globalFences: readonly GlobalFence[];
    globalDependencies: readonly GlobalDependency[];
    recentSourceIds: readonly string[];
    recent: readonly {
        id: string;
        role: string;
        text: string;
    }[];
    text: string;
    dependencyIds: readonly string[];
    droppedOptionalIds: readonly string[];
    budget: RuntimeBudget;
    proof: PacketProof;
    optimizer: 'standalone' | 'ultra-rp/v1';
}
export declare function validateBudget(b: RuntimeBudget): void;
/** Includes every serialized field, preserving overhead. Heuristic, never billing. */
export declare function estimateFinalRequest(request: unknown): number;
export declare function createPacketService(store: RpStore, global: Awaited<ReturnType<typeof openRpGlobalStore>>, options?: {
    optimizer?: () => RecallOptimizer | undefined;
}): Readonly<{
    prepare(authority: HostAuthority, input: {
        budget: RuntimeBudget;
        globalAuthorities: readonly object[];
        inputBindings: readonly InputBinding[];
        optionalTokens?: number;
        personId?: string;
        runtime?: ModuleContext;
    }): Promise<Result<MemoryPacket>>;
    admit(authority: HostAuthority, packet: MemoryPacket, request: Record<string, unknown>): Promise<{
        ok: false;
        code: import("./types.js").ErrorCode;
        message: string;
    } | {
        ok: true;
        value: {
            packetId: string;
            inputTokens: number;
            reserve: number;
            effective: number;
            totalTokens: number;
            mode: "estimated";
            limited: boolean;
        };
    }>;
}>;
