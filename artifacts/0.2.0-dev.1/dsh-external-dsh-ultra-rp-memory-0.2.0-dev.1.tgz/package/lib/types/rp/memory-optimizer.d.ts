export interface RecallCandidate {
    readonly id: string;
    readonly text: string;
    readonly kind: 'experience' | 'summary';
    readonly sequence: number;
}
export interface RecallOptimizer {
    readonly protocol: 'ultra-rp/v1';
    rank(input: {
        readonly query: string;
        readonly maxRecords: number;
        readonly candidates: readonly RecallCandidate[];
    }): readonly string[];
}
export declare function createUltraRpOptimizer(): RecallOptimizer;
