import type { AuthorityChange, SemanticEvent } from './types.js';
export type SemanticProtocol = 'agent-memory/v1' | 'person-core/v1' | 'person-origin/v1';
export declare const semanticProtocol: (event: object) => SemanticProtocol | undefined;
export declare const markSemantic: (event: object, protocol: SemanticProtocol) => void;
export declare const personOriginCandidate: (personId: string) => string;
export declare function markerProtocol(changes: readonly AuthorityChange[], event: SemanticEvent): SemanticProtocol | undefined;
export declare const hasPersonOwner: (changes: readonly AuthorityChange[], personId: string) => boolean;
export declare const requiresPerson: (changes: readonly AuthorityChange[]) => boolean;
export declare function inheritSemanticMarks(from: unknown, to: unknown, seen?: WeakSet<object>): void;
