import type { RpStore } from './store.js';
import type { HostAuthority, InputFence } from './types.js';
import { type RetrievalRecord } from './retrieval-index.js';
export type RetrievalRecordRef = Readonly<Pick<RetrievalRecord, 'id' | 'revision' | 'kind'>>;
export type RetrievalEvidence = Readonly<{
    inputFence: InputFence;
    records: readonly RetrievalRecordRef[];
    resultSha256: string;
}>;
export declare function bindRetrievalEvidence<T extends object>(result: T, authority: HostAuthority, inputFence: InputFence, records: readonly RetrievalRecordRef[]): T;
export declare function retrievalEvidence(result: object, authority: HostAuthority): RetrievalEvidence;
export declare function verifyRetrievalEvidence(store: RpStore, authority: HostAuthority, proof: RetrievalEvidence, inputs: ReadonlySet<string>): Promise<InputFence>;
