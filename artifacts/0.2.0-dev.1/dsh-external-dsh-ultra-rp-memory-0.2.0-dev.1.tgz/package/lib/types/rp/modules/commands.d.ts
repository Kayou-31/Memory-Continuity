import { type RuntimeConfig } from './contract.js';
import { type ModuleRuntime } from './runtime.js';
export declare function runtimeCommand(action: string, arg: string, key: string, host: {
    config: RuntimeConfig;
    runtime?: ModuleRuntime;
    ready: () => Promise<void>;
    change: (config: RuntimeConfig, disable: boolean) => Promise<void>;
}): Promise<{
    kind: "success";
    text: string;
}>;
