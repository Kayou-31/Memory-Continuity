import type { RuntimeBinding } from './contract.js';
export declare function runtimeMarkerValid(root: string, session: string, workspace: string, binding: RuntimeBinding): Promise<boolean>;
export declare function writeRuntimeMarker(root: string, session: string, workspace: string, binding: RuntimeBinding | undefined, blocked: boolean): Promise<void>;
