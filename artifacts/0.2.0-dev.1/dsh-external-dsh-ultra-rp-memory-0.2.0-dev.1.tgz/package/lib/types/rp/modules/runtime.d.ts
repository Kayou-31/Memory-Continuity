import { type RpStore } from '../store.js';
import type { HostAuthority, InputFence } from '../types.js';
import type { MemoryCoordinator } from '../session-policy.js';
import { type RetrievalRecordRef } from '../retrieval-evidence.js';
import { type RuntimeBinding } from './contract.js';
export interface ModuleReceipt {
    protocol: 'rp.module-result/v1';
    callId: string;
    moduleId: string;
    moduleVersion: string;
    bindingSha256: string;
    inputFence: InputFence;
    records: readonly RetrievalRecordRef[];
    resultSha256: string;
    execution: 'core-only';
}
export declare const moduleDisplay: (value: unknown, receipt: ModuleReceipt) => {
    result: unknown;
    receipt: ModuleReceipt;
    notice: string;
};
/** Context and result handles are process-local capabilities, never JSON grants. */
export interface ModuleContext {
    readonly binding: RuntimeBinding;
}
export declare function resolveModuleContext(context: ModuleContext, authority: HostAuthority): {
    hardConstraints: Readonly<{
        automaticAdoption: false;
        backgroundExecution: false;
        externalExecution: false;
        authority: "host-only";
        evidence: "original-result-and-fence";
        guidance: "advisory-not-permission";
    }>;
    protocol: "rp.runtime-binding/v1";
    registrySha256: string;
    config: import("./contract.js").RuntimeConfig;
    sha256: string;
};
export type ModuleRuntime = ReturnType<ReturnType<typeof createModuleService>['create']>;
export declare function createModuleService(store: RpStore, coordinator: MemoryCoordinator, entityIds: readonly string[], inputs: (a: HostAuthority) => ReadonlySet<string>): Readonly<{
    registry: readonly import("./contract.js").ModuleManifest[];
    create(authority: HostAuthority, config?: unknown, active?: () => boolean): Readonly<{
        binding: () => RuntimeBinding;
        context: () => ModuleContext;
        revoke: () => void;
        run(moduleId: string, input: unknown, key?: string): Promise<{
            value: unknown;
        }>;
        verify(result: object): Promise<ModuleReceipt>;
    }>;
}>;
