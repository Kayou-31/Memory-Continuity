export declare const MODES: readonly ["rp", "companion", "creation", "project"];
export type Purpose = typeof MODES[number];
export type Capability = 'read-person' | 'read-records' | 'propose-growth';
export interface ModuleManifest {
    protocol: 'rp.module/v1';
    id: string;
    version: string;
    coreVersion: 'rp.modules/v1';
    capabilities: readonly Capability[];
    output: 'person-view' | 'records' | 'growth-candidate';
    modes: readonly Purpose[];
    shutdown: 'revoke';
}
export declare const MODULES: readonly ModuleManifest[];
export interface Constraints {
    maxReadRecords: number;
    maxOutputBytes: number;
    deniedCapabilities: Capability[];
    protectedFieldIds: string[];
    guidance: {
        id: string;
        text: string;
    }[];
}
export interface RuntimeConfig {
    mode: Purpose;
    enabledModules: string[];
    constraints: Constraints;
}
export interface RuntimeBinding {
    protocol: 'rp.runtime-binding/v1';
    registrySha256: string;
    config: RuntimeConfig;
    sha256: string;
}
export declare const digest: (value: unknown) => string;
export declare const HARD_CONSTRAINTS: Readonly<{
    automaticAdoption: false;
    backgroundExecution: false;
    externalExecution: false;
    authority: "host-only";
    evidence: "original-result-and-fence";
    guidance: "advisory-not-permission";
}>;
export declare function runtimeConfig(input?: unknown): RuntimeConfig;
export declare function createRuntimeBinding(input?: unknown): RuntimeBinding;
export declare function validateRuntimeBinding(input: unknown): asserts input is RuntimeBinding;
