import type { AuthorityChange, JsonValue, SemanticEvent } from './types.js';
import { inheritSemanticMarks } from './semantic-registry.js';
export declare const hasGrowthMarker: (changes: readonly AuthorityChange[], eventId: string) => boolean;
/** Only a verified authority-ledger marker opts an event into growth semantics. */
export declare function markGrowthEvent(event: SemanticEvent): void;
export declare const inheritGrowthMarks: typeof inheritSemanticMarks;
export interface GrowthValue {
    protocol: 'agent-memory/v1';
    channel: 'state' | 'relationship' | 'goal';
    value: JsonValue;
    previousEventId: string | null;
    causeEventIds: string[];
    note: string;
}
export interface GoalValue {
    goalId: string;
    category: 'task' | 'promise';
    objective: string;
    status: 'active' | 'paused' | 'completed' | 'abandoned';
    progress: number;
    nextAction: string;
    targetEntityId?: string;
}
export declare function goalValue(input: unknown): GoalValue;
export declare function growthValue(event: SemanticEvent): GrowthValue | null;
export declare function growthSlot(event: SemanticEvent): string | null;
export declare function projectedStateKey(event: SemanticEvent): string;
export declare function currentGrowthHeads(events: readonly SemanticEvent[]): SemanticEvent[];
export declare function projectedEventValue(event: SemanticEvent): JsonValue;
export declare function checkGrowthTransition(event: SemanticEvent, history: readonly SemanticEvent[]): void;
