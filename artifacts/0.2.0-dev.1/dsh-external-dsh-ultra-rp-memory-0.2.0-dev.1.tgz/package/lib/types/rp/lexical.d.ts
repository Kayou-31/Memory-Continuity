export declare function queryGroups(query: string): string[][];
export declare function lexicalScore(body: string, groups: readonly string[][]): number | null;
export declare function hitExcerpt(body: string, query: string, maxChars?: number): string;
