/** Explicit source observation only. This adapter subscribes to no host event
 * and never treats a completed generation as accepted/canonical. Its public
 * text projection follows evidence.ts / memory-host.publicEvidence's primitive
 * (text blocks joined by LF), without initializing engineering MemoryRun. */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { RpStore } from './store.js';
import type { HostAuthority, HostSourceLocator, Result, SourceRevision } from './types.js';
export interface PublicHostObservation {
    readonly idempotencyKey: string;
    readonly host: HostSourceLocator;
    readonly turnId: string;
    readonly event: SessionEvent;
}
export declare function observePublicHostSource(store: RpStore, authority: HostAuthority, input: PublicHostObservation): Promise<Result<SourceRevision>>;
