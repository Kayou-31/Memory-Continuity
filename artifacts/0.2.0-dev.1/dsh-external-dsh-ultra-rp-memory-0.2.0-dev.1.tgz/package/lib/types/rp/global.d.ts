import type { CanonBinding, Result, Scope, SourceRevision, Visibility } from './types.js';
import { MemoryCoordinator } from './session-policy.js';
export type GlobalScope = Extract<Scope, {
    kind: 'profile' | 'world';
}>;
export interface GlobalFence {
    scope: GlobalScope;
    scopeRevision: number;
    visibilityRevision: number;
    deletionGeneration: number;
}
export interface GlobalPublication {
    id: string;
    key: string;
    scope: GlobalScope;
    revision: number;
    body: string;
    bodySha256: string;
    source: SourceRevision;
    supersedes: string | null;
    verification: 'source-match' | 'private-source-deleted';
}
export interface Grant {
    scope: GlobalScope;
    visibility: Visibility;
    audienceSetIds: string[];
    write: boolean;
}
type Publish = {
    idempotencyKey: string;
    expected: GlobalFence;
    key: string;
    body: string;
    privateSourceIds: readonly string[];
    supersedes?: string;
};
export declare function openRpGlobalStore(profileRoot: string, coordinator?: MemoryCoordinator): Promise<{
    store: {
        storageStatus(authority: object): Promise<Result<{
            logicalBytes: number;
            seq: number;
            publicationLimitBytes: number;
            controlLimitBytes: number;
            backupId?: string | undefined;
            backupSha256?: string | undefined;
            format: string;
        }>>;
        listActive(authority: object): Promise<Result<GlobalPublication[]>>;
        readFence(authority: object): Promise<Result<GlobalFence>>;
        readPublication: (authority: object, publicationId: string) => Promise<Result<GlobalPublication>>;
        list(authority: object): Promise<Result<GlobalPublication[]>>;
        verifyBinding(authority: object, binding: CanonBinding): Promise<boolean>;
    };
    control: {
        enableSegments(authority: object, approval: object, input: {
            idempotencyKey: string;
            expected: GlobalFence;
        }): Promise<Result<GlobalFence>>;
        purgeStatus(authority: object): Promise<Result<{
            publicationId: string;
            purgeState: string;
        }[]>>;
        isApproval(handle: object): boolean;
        authorize(input: Grant): Promise<Result<object>>;
        revokeAuthority(authority: object): Promise<void>;
        recoverWriterLock(authority: object): Promise<Result<"unlocked" | "recovered">>;
        approval(input: {
            commandId: string;
            sessionId: string;
        }): Readonly<{}>;
        revokeApproval(handle: object): void;
        publish(authority: object, approval: object, input: Publish): Promise<Result<GlobalPublication>>;
        privateDeletion(authority: object, approval: object, input: {
            idempotencyKey: string;
            expected: GlobalFence;
            privateSourceIds: readonly string[];
            publicationDisposition: "retain" | "delete";
        }): Promise<Result<GlobalFence>>;
        revoke(authority: object, approval: object, input: {
            idempotencyKey: string;
            expected: GlobalFence;
            publicationId: string;
        }): Promise<Result<GlobalFence>>;
    };
}>;
export {};
