/** All dynamic text is rendered with textContent; no profile data in HTML. */
export declare function managerPage(nonce: string): string;
