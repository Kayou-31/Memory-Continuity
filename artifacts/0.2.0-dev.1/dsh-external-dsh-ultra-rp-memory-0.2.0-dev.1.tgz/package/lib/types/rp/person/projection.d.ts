import type { RpReadView } from '../store.js';
export declare function projectPerson(view: RpReadView, personId: string): {
    personId: string;
    originEventId: string;
    fence: import("../types.js").InputFence;
    fields: {
        eventId: string;
        protocol: "person-core/v1";
        operation: "init" | "edit" | "grow" | "set-policy";
        previousEventId: string | null;
        causeEventIds: string[];
        note: string;
        fieldId: string;
        kind: import("./types.js").PersonFieldKind;
        value: string;
        policy: import("./types.js").PersonPolicy;
        validity?: import("./types.js").PersonValidity;
    }[];
    relationships: import("../types.js").RelationshipProjection[];
    goals: import("../types.js").StateProjection[];
};
