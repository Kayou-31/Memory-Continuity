import type { PersonDraft } from './types.js';
/** Reserve imported identifiers too; removed rows need not recycle their IDs. */
export declare function createDraftIds(draft: PersonDraft): (prefix: string) => string;
