import { type RpStore } from '../store.js';
import type { HostAuthority, InputFence } from '../types.js';
export interface PersonBinding {
    protocol: 'rp.person-binding/v1';
    personId: string;
    originEventId: string;
    originSha256: string;
    boundAt: InputFence;
}
export declare function validatePersonBinding(input: unknown): asserts input is PersonBinding;
export declare function createPersonBinding(store: RpStore, authority: HostAuthority, personId: string): Promise<PersonBinding>;
export declare function verifyPersonBinding(store: RpStore, authority: HostAuthority, binding: PersonBinding): Promise<void>;
