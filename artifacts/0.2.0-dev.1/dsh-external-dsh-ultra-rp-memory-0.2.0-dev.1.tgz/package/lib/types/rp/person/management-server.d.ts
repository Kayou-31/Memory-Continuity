import type { ManagementController } from './management.js';
export declare function openManagementServer(controller: ManagementController, context?: () => unknown, changed?: () => Promise<void>): Promise<{
    url: string;
    revoke(): void;
    close(): Promise<void>;
}>;
