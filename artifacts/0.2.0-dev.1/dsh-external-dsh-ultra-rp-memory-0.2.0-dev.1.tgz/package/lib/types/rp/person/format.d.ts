import type { SemanticEvent } from '../types.js';
import type { PersonValue } from './types.js';
export declare function personValue(event: SemanticEvent): PersonValue | null;
export declare function checkPersonTransition(event: SemanticEvent, history: readonly SemanticEvent[]): void;
export declare function personApplies(event: SemanticEvent, context?: {
    sceneId?: string;
    acceptedSeq: number;
}): boolean;
