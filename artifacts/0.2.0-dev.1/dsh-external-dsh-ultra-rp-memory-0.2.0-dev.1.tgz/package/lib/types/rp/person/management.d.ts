import { type RpStore } from '../store.js';
import { createCanonicalService } from '../canonical.js';
import type { HostAuthority, InputFence } from '../types.js';
import type { MemoryCoordinator } from '../session-policy.js';
export declare function createManagementService(store: RpStore, control: Parameters<typeof createCanonicalService>[1], entities: readonly string[], coordinator: MemoryCoordinator): Readonly<{
    create(authority: HostAuthority, active?: () => boolean): Readonly<{
        revoke(): void;
        snapshot(): Promise<{
            candidates: {
                state: any;
                protocol: "person-growth/v1";
                id: string;
                inputFence: InputFence;
                changes: ({
                    changeId: string;
                    personId: string;
                    fieldId: string;
                    previousEventId: string | null;
                    previousChangeId?: string;
                    value: string;
                    causeEventIds: string[];
                    note: string;
                } & {
                    eventId: string;
                })[];
            }[];
            timelines: {
                changes: {
                    eventId: string;
                    acceptedSeq: number;
                    fictionalTime: string | null;
                    sourceRevisionIds: string[];
                    current: boolean;
                    expired: boolean;
                    protocol: "person-core/v1";
                    operation: "init" | "edit" | "grow" | "set-policy";
                    previousEventId: string | null;
                    causeEventIds: string[];
                    note: string;
                    fieldId: string;
                    kind: import("./types.js").PersonFieldKind;
                    value: string;
                    policy: import("./types.js").PersonPolicy;
                    validity?: import("./types.js").PersonValidity;
                }[];
                changeCount: number;
                personId: string;
                fence: InputFence;
                originEventId: string;
                invalidatedEventIds: string[];
            }[];
            notice: string;
            fence: InputFence;
            persons: {
                personId: string;
                originEventId: string;
                fence: InputFence;
                fields: {
                    eventId: string;
                    protocol: "person-core/v1";
                    operation: "init" | "edit" | "grow" | "set-policy";
                    previousEventId: string | null;
                    causeEventIds: string[];
                    note: string;
                    fieldId: string;
                    kind: import("./types.js").PersonFieldKind;
                    value: string;
                    policy: import("./types.js").PersonPolicy;
                    validity?: import("./types.js").PersonValidity;
                }[];
                relationships: import("../types.js").RelationshipProjection[];
                goals: import("../types.js").StateProjection[];
            }[];
            experiences: import("../types.js").SemanticEvent[];
            experienceCount: number;
            id: string;
            entityIds: string[];
        }>;
        prepare(input: unknown): Promise<{
            id: string;
            action: string;
            payload: any;
            fence: InputFence;
            notice: string;
        }>;
        confirm(id: string): Promise<unknown>;
    }>;
}>;
export type ManagementController = ReturnType<ReturnType<typeof createManagementService>['create']>;
