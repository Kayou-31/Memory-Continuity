import type { PersonDraft, PersonField } from './types.js';
export declare const personKeys: Record<PersonField['kind'], string>;
export declare function personField(input: unknown): asserts input is PersonField;
export declare function personDraft(input: unknown, known: ReadonlySet<string>): PersonDraft;
