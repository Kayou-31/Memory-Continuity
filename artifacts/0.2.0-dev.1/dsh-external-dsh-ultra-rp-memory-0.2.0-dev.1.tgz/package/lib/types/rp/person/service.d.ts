import { type RpStore } from '../store.js';
import type { createCanonicalService } from '../canonical.js';
import type { HostAuthority, InputFence, SourceRevision } from '../types.js';
import type { PersonDraft } from './types.js';
export declare function createPersonService(store: RpStore, service: ReturnType<typeof createCanonicalService>, entityIds: readonly string[]): Readonly<{
    preview(authority: HostAuthority, input: unknown, key: string): Promise<{
        ok: false;
        code: import("../types.js").ErrorCode;
        message: string;
    } | {
        ok: true;
        value: {
            handle: Readonly<{}>;
            personId: string;
            draftHash: string;
            inputFence: InputFence;
            draft: PersonDraft;
            backupRequired: boolean;
        };
    }>;
    confirm(authority: HostAuthority, handle: object, controlSource: SourceRevision): Promise<{
        readonly ok: false;
        readonly code: import("../types.js").ErrorCode;
        readonly message: string;
    } | {
        ok: true;
        value: {
            personId: string;
            originEventId: string;
            fence: InputFence;
        };
    }>;
    read(authority: HostAuthority, personId: string): Promise<import("../types.js").Result<{
        personId: string;
        originEventId: string;
        fence: InputFence;
        fields: {
            eventId: string;
            protocol: "person-core/v1";
            operation: "init" | "edit" | "grow" | "set-policy";
            previousEventId: string | null;
            causeEventIds: string[];
            note: string;
            fieldId: string;
            kind: import("./types.js").PersonFieldKind;
            value: string;
            policy: import("./types.js").PersonPolicy;
            validity?: import("./types.js").PersonValidity;
        }[];
        relationships: import("../types.js").RelationshipProjection[];
        goals: import("../types.js").StateProjection[];
    }>>;
    apply(authority: HostAuthority, control: SourceRevision, input: unknown): Promise<{
        ok: false;
        code: import("../types.js").ErrorCode;
        message: string;
    } | {
        ok: true;
        value: {
            eventId: string;
            fence: InputFence | import("../types.js").PrivacyDeletion;
        };
    }>;
    propose: (authority: HostAuthority, input: unknown, key: string, expected?: InputFence) => Promise<import("../types.js").Result<{
        protocol: "person-growth/v1";
        id: string;
        inputFence: InputFence;
        changes: ({
            changeId: string;
            personId: string;
            fieldId: string;
            previousEventId: string | null;
            previousChangeId?: string;
            value: string;
            causeEventIds: string[];
            note: string;
        } & {
            eventId: string;
        })[];
    }>>;
    list(authority: HostAuthority): Promise<import("../types.js").Result<{
        state: any;
        protocol: "person-growth/v1";
        id: string;
        inputFence: InputFence;
        changes: ({
            changeId: string;
            personId: string;
            fieldId: string;
            previousEventId: string | null;
            previousChangeId?: string;
            value: string;
            causeEventIds: string[];
            note: string;
        } & {
            eventId: string;
        })[];
    }[]>>;
    adopt(authority: HostAuthority, control: SourceRevision, candidateIds: readonly string[], key: string): Promise<{
        ok: false;
        code: import("../types.js").ErrorCode;
        message: string;
    } | {
        ok: true;
        value: {
            fence: InputFence | import("../types.js").PrivacyDeletion;
        };
    }>;
    reject(authority: HostAuthority, control: SourceRevision, candidateId: string, key: string, originalExpected?: InputFence): Promise<{
        readonly ok: false;
        readonly code: import("../types.js").ErrorCode;
        readonly message: string;
    } | {
        readonly ok: true;
        readonly value: InputFence;
    } | {
        readonly ok: true;
        readonly value: import("../types.js").PrivacyDeletion;
    }>;
    timeline(authority: HostAuthority, personId: string): Promise<import("../types.js").Result<{
        personId: string;
        fence: InputFence;
        originEventId: string;
        changes: {
            eventId: string;
            acceptedSeq: number;
            fictionalTime: string | null;
            sourceRevisionIds: string[];
            current: boolean;
            expired: boolean;
            protocol: "person-core/v1";
            operation: "init" | "edit" | "grow" | "set-policy";
            previousEventId: string | null;
            causeEventIds: string[];
            note: string;
            fieldId: string;
            kind: import("./types.js").PersonFieldKind;
            value: string;
            policy: import("./types.js").PersonPolicy;
            validity?: import("./types.js").PersonValidity;
        }[];
        invalidatedEventIds: string[];
    }>>;
}>;
