import { type RpStore } from './store.js';
import type { HostAuthority, ProjectionResult, SemanticEvent, Summary } from './types.js';
export interface PacketProof {
    readonly records: readonly {
        readonly id: string;
        readonly kind: 'event' | 'summary';
        readonly revision: string;
    }[];
    readonly projectionSha256: string;
}
export declare function validatePacketProof(input: unknown): asserts input is PacketProof;
export declare function capturePacketProof(events: readonly SemanticEvent[], summaries: readonly Summary[], projection: ProjectionResult): PacketProof;
export declare function verifyPacketProof(store: RpStore, authority: HostAuthority, proof: PacketProof | undefined): Promise<void>;
