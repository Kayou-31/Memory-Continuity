/** Public Cordis entry. Implementation is maintained once in src/rp. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { installRpPlugin, type RpPluginConfig } from './rp/rp-plugin.js';
export { installRpPlugin };
export { openRpMemory, createUltraRpOptimizer } from './rp/memory.js';
export type { AgentMemoryControl } from './rp/agent-memory.js';
export type { RuntimeConfig, RuntimeBinding, ModuleManifest, Capability, Constraints, Purpose } from './rp/modules/contract.js';
export type { ModuleRuntime, ModuleReceipt, ModuleContext } from './rp/modules/runtime.js';
export type { RpPluginConfig };
export declare const name = "@dsh-external/dsh-ultra-rp-memory";
export declare const inject: string[];
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    enabled: z<boolean, boolean, "defined">;
    contextCompression: z<boolean, boolean, "defined">;
    strictPov: z<boolean, boolean, "defined">;
    profileRoot: z<string, string, "plain">;
    workspaceRoot: z<string, string, "plain">;
    campaignId: z<string, string, "plain">;
    entityIds: z<string[], string[], "defined">;
    knownCooperatingWriters: z<boolean, boolean, "defined">;
    ultraMemoryOptimization: z<boolean, boolean, "defined">;
    budget: z<any, any, "plain">;
    globalGrants: z<any[], any[], "plain">;
}>>, Schemastery.ObjectT<NoInfer<{
    enabled: z<boolean, boolean, "defined">;
    contextCompression: z<boolean, boolean, "defined">;
    strictPov: z<boolean, boolean, "defined">;
    profileRoot: z<string, string, "plain">;
    workspaceRoot: z<string, string, "plain">;
    campaignId: z<string, string, "plain">;
    entityIds: z<string[], string[], "defined">;
    knownCooperatingWriters: z<boolean, boolean, "defined">;
    ultraMemoryOptimization: z<boolean, boolean, "defined">;
    budget: z<any, any, "plain">;
    globalGrants: z<any[], any[], "plain">;
}>>, "plain">;
export type Config = RpPluginConfig;
export declare function apply(ctx: Context, config: Config): Promise<void>;
